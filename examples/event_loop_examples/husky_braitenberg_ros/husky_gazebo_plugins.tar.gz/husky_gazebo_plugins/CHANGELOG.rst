^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package husky_gazebo_plugins
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.0.3 (2013-11-01)
------------------
* a fix for husky odometry message rotating about the wrong axis

0.0.2 (2013-09-30)
------------------
* added package installation rules

0.0.1 (2013-09-29)
------------------
* Initial release for Hydro.
